---
title: 'Modern Hospital'
date: 2018-11-18T12:33:46+10:00
draft: false
weight: 2
heroHeading: 'Modern Hospital Design'
heroSubHeading: 'Designing a new modern hospital wing'
heroBackground: 'https://source.unsplash.com/iqGtaQnk3VM/1600x400'
thumbnail: 'https://source.unsplash.com/iqGtaQnk3VM/600x400'
images: ['https://source.unsplash.com/random/400x600/?nature', 
'https://source.unsplash.com/random/400x300/?travel','https://source.unsplash.com/random/400x300/?architecture','https://source.unsplash.com/random/400x600/?buildings','https://source.unsplash.com/random/400x300/?city','https://source.unsplash.com/random/400x600/?business']
---

Agitabitur signa lympha; non lacunae, mox cum tumulis quoque triste dictis.
Ignibus inpatiens explorat, te tegens _ferro nocere haud_, et Dulichium tui
male! Quo sed [fuit flexit et](#vexant-achivi) hic die solido, gloria?

Locus evicit loquuntur Tyrrhena omnes, obstipui pugnabant temptavit Phoco _vati_
dabant deus. Memorata haberet sepulcrales gentisque dum sic, in flumina templa!
Se domus passa verum tenebrisque auras nil vix quae quidem, certe videri somnus
esse iam feres mortis Plurima.
