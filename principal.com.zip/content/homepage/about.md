---
title: 'Our Difference'
weight: 2
background: ''
button: 'About Us'
buttonLink: 'about'
---

At Principal Economics we help our clients to find practical robust solutions in a timely manner by prioritising clients’ problem, using frontier economic thinking and our familiarity with a wide range of data and frontier methodologies.
