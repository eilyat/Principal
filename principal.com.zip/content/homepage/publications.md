---
title: 'Frontier economics, practical applications'
weight: 1
background: 'images/kevin-bhagat-461952-unsplash.jpg'
button: 'Our Work'
buttonLink: 'work'
---

Principal Economics provides economic consultancy services to a wide range of public and private clients.

