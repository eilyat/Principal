---
date: "2018-02-12T15:37:57+07:00"
heroBackground: images/jason-blackeye-1191801-unsplash.jpg
heroHeading: Principal Economics
heroSubHeading: Practical robust solutions using economic thinking and our familiarity with a wide range of data and frontier methodologies.


title: Home
---
