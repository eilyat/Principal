---
date: "2018-12-06T09:29:16+10:00"
heroBackground: https://source.unsplash.com/sO-JmQj95ec/1600x1000
heroHeading: About Us
heroSubHeading: Principal Economics provides economic consultancy services to a wide range of public and private clients. 
layout: aboutlayout
title: About
---

<div>
{{< content-strip-left "/pages/about" "content1" >}}
</div>
<div>
{{< content-strip-right "/pages/about" "content2" >}}
</div>
<div>
{{< content-strip-center "/pages/about" "content3" >}}
</div>
