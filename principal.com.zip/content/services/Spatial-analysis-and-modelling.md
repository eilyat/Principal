---
date: "2018-11-28T15:14:39+10:00"
draft: false
featured: true
heroBackground: services/service2.jpg
heroHeading: Spatial analysis and modelling
heroSubHeading: Expert advice and guidance when you need it most.
icon: services/service-icon-2.png
title: Spatial analysis and modelling
---

The relationships between your investment/intervention and the activities of businesses and households in neighbouring areas.
