---
date: "2018-11-28T15:14:54+10:00"
draft: false
featured: true
heroBackground: services/service1.jpg
heroHeading: Market analysis
heroSubHeading: Saving for retirement requires careful planning.
icon: services/service-icon-5.png
title: Market analysis
---

Understand the trend of the market and potential impact from your investment on the rest of the market and the regional economy.