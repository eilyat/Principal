---
date: "2018-11-18T12:33:46+10:00"
draft: false
featured: true
heroBackground: services/service2.jpg
heroHeading: 'Forecasting and modelling'
heroSubHeading: Preparing and filing your tax return
icon: services/service-icon-6.png
title: Forecasting and modelling
weight: 2
---

Assist with your planning for future investments using best available data and time series analysis.
