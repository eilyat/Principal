---
date: "2018-11-28T15:15:26+10:00"
draft: false
featured: true
heroBackground: services/service1.jpg
heroHeading: Economic research
heroSubHeading: We can help value your business and prepare it for sale.
icon: services/service-icon-3.png
title: Economic research
---

Test a range of hypotheses using data and econometric techniques.
