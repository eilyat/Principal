---
date: "2018-11-28T15:15:34+10:00"
draft: false
featured: true
heroBackground: services/service2.jpg
heroHeading: Economic impact analysis
heroSubHeading: Thinking of acquiring another business? Let us guide you through the process.
icon: services/service-icon-4.png
title: Economic impact analysis
---

Estimate the impact of your activities using our extensive economic assessment frameworks