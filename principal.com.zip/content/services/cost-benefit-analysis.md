---
date: "2018-11-18T12:33:46+10:00"
draft: false
featured: true
heroBackground: services/service1.jpg
heroHeading: Cost benefit analysis
heroSubHeading: We offer general accouting on hourly rate or fixed fee
icon: services/service-icon-1.png
title: Cost benefit analysis
weight: 1
---

Making decisions in uncertain times needs precise understanding of the costs and benefits. We can assist by identifying fiscal, economic and wellbeing benefits from your investment decision or policy intervention.