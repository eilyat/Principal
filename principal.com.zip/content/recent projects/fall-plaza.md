---
date: "2018-11-18T12:33:46+10:00"
draft: false
heroBackground: work/work1.jpg
heroHeading: Fall Plaza
heroSubHeading: Revitalising a public space in Spain.
images:
- https://source.unsplash.com/random/400x600/?nature
- https://source.unsplash.com/random/400x300/?travel
- https://source.unsplash.com/random/400x300/?architecture
- https://source.unsplash.com/random/400x600/?buildings
- https://source.unsplash.com/random/400x300/?city
- https://source.unsplash.com/random/400x600/?business
thumbnail: work/work1-thumbnail.jpg
title: Fall Plaza
weight: 1
---

Adfas