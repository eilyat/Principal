---
date: "2018-11-18T12:33:46+10:00"
draft: false
heroBackground: https://source.unsplash.com/iqGtaQnk3VM/1600x400
heroHeading: Modern Hospital Design
heroSubHeading: Designing a new modern hospital wing
images:
- https://source.unsplash.com/random/400x600/?nature
- https://source.unsplash.com/random/400x300/?travel
- https://source.unsplash.com/random/400x300/?architecture
- https://source.unsplash.com/random/400x600/?buildings
- https://source.unsplash.com/random/400x300/?city
- https://source.unsplash.com/random/400x600/?business
thumbnail: https://source.unsplash.com/a8YV2C3yBMk/600x400
title: Tourism industry
weight: 1
---

Economic impact of regional investments in tourism industry.