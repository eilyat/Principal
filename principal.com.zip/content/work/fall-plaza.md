---
date: "2018-11-18T12:33:46+10:00"
draft: false
heroBackground: work/work1.jpg
heroHeading: Fall Plaza
heroSubHeading: Revitalising a public space in Spain.
images:
- https://source.unsplash.com/random/400x600/?nature
- https://source.unsplash.com/random/400x300/?travel
- https://source.unsplash.com/random/400x300/?architecture
- https://source.unsplash.com/random/400x600/?buildings
- https://source.unsplash.com/random/400x300/?city
- https://source.unsplash.com/random/400x600/?business
thumbnail: https://source.unsplash.com/P_2za841j_w/600x400
title: Economic impact of COVID-19
weight: 1
---

Assist with assessment of the impact of COVID-19 on demand for your investments.