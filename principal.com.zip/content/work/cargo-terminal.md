---
date: "2018-11-18T12:33:46+10:00"
draft: false
heroBackground: https://source.unsplash.com/tjX_sniNzgQ/1600x400
heroHeading: Investments in industries
heroSubHeading: Investments in industries

thumbnail: https://source.unsplash.com/f_LqKQylUn4/800x600
title: Investments in the energy sector
weight: 3
---

Providing advice and forecasts of the areas of investment in the energy sector.
